//
//  SwiftUiButtonStateApp.swift
//  SwiftUiButtonState
//
//  Created by Bandenawaz Bagwan on 30/11/22.
//

import SwiftUI

@main
struct SwiftUiButtonStateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
