//
//  SwiftUIImageApp.swift
//  SwiftUIImage
//
//  Created by Bandenawaz Bagwan on 30/11/22.
//

import SwiftUI

@main
struct SwiftUIImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
