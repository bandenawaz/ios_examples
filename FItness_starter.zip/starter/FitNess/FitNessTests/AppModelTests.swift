/// Copyright (c) 2022 Razeware LLC

import XCTest
import FitNess



final class AppModelTests: XCTestCase {

  var sut: AppModel!
  override func setUpWithError() throws {
    
    try super.setUpWithError()
    sut = AppModel()
  }
  
  override func tearDownWithError() throws {
     sut = nil
    try super.tearDownWithError()
  }
  
  func testAppModel_whenInitialized_isInNotStartedState(){
    
    let sut = AppModel()
    let initialState = sut.appState
    XCTAssertEqual(initialState, AppState.notStarted)
  }
  
  func testAppModel_whenStarted_isInProgressState(){
    
    let sut = AppModel()
    
    sut.start()
    
    let observedState = sut.appState
    XCTAssertEqual(observedState, AppState.inProgress)
  }

}
