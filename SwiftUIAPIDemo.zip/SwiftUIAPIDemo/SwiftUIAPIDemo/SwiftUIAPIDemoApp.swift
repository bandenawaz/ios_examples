//
//  SwiftUIAPIDemoApp.swift
//  SwiftUIAPIDemo
//
//  Created by Bandenawaz Bagwan on 01/12/22.
//

import SwiftUI

@main
struct SwiftUIAPIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
