//
//  MovieGridCell.swift
//  Flixy
//
//  Created by Tasneem Hasanat on 9/18/22.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
